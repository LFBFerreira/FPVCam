package space.luis.video;

import processing.core.*;


public class FpvCam extends PApplet {

    private PApplet parent;

    public FpvCam(PApplet parent) {
        this.parent = parent;
    }

    // ================================================================

    /**
     * Processing's dispose function, frees all resources
     */
    public void dispose() {
    }


    // -----------------------------------------------------------------------------------------------------------------

}

