package space.luis.video.test;

import java.io.File;
import java.io.IOException;

import static processing.core.PApplet.runSketch;

public class SketchLauncher {
    private static final int DISPLAY_INDEX = 2; // 1 -> Main Screen, 2 -> Second Screen

    public static void main(String[] args){

        TestSketch sketch = new TestSketch();

        String sketchPath = "";

        try {
            sketchPath = new File(".").getCanonicalPath().toString();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String[] localArgs = new String[]{"--display=" + DISPLAY_INDEX,
                "--sketch-path=" + sketchPath,
                sketch.getClass().getSimpleName()};

        runSketch(localArgs, sketch);
    }
}